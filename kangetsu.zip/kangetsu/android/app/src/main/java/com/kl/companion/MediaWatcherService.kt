package com.kl.companion

import android.service.notification.NotificationListenerService
import android.util.Log

/**
 * Having this service enabled under "Notification access" is what authorises getActiveSessions().
 * The system keeps it bound, so the local HTTP server lives as long as the service does.
 */
class MediaWatcherService : NotificationListenerService() {
    private var http: TinyHttp? = null

    override fun onListenerConnected() { startServer() }
    override fun onCreate() { super.onCreate(); startServer() }

    private fun startServer() {
        if (http != null) return
        try {
            http = TinyHttp(PORT) { path ->
                when (path) {
                    "/now" -> State.nowBody(applicationContext)
                    "/lyrics" -> State.lyricsBody()
                    else -> null
                }
            }.also { it.start() }
            Log.i(TAG, "listening on 127.0.0.1:$PORT")
        } catch (e: Exception) { Log.e(TAG, "cannot start server", e); http = null }
    }

    override fun onDestroy() { http?.stop(); http = null; super.onDestroy() }

    companion object { const val PORT = 19133; const val TAG = "KLCompanion" }
}
