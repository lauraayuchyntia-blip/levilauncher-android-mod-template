package com.kl.companion

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        status = TextView(this).apply { textSize = 15f }
        root.addView(TextView(this).apply { text = "Kangetsu Lyrics Companion"; textSize = 20f })
        root.addView(TextView(this).apply {
            text = "1) Turn on notification access for this app.\n2) Exempt it from battery optimisation.\n" +
                "3) Play a song, then start Minecraft from LeviLauncher.\nServing on 127.0.0.1:${MediaWatcherService.PORT}\n"
        })
        root.addView(Button(this).apply {
            text = "Open notification access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Battery optimisation settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })
        root.addView(Button(this).apply { text = "Refresh"; setOnClickListener { refresh() } })
        root.addView(status)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val s = try { NowPlaying.read(this) } catch (e: Exception) { null }
        status.text = if (s == null) "Nothing detected (is notification access on, and a song playing?)"
        else "Now playing: ${s.title} - ${s.artist}\nPosition: ${s.posMs / 1000}s / ${s.durMs / 1000}s  (${s.pkg})"
    }
}
