package com.kl.companion

import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

/** Minimal HTTP/1.1 server bound to 127.0.0.1 only: GET /now and GET /lyrics. */
class TinyHttp(private val port: Int, private val handler: (path: String) -> String?) {
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var running = false

    fun start() {
        if (running) return
        running = true
        server = ServerSocket(port, 8, InetAddress.getByName("127.0.0.1"))
        pool.execute {
            while (running) {
                val s = try { server!!.accept() } catch (e: Exception) { break }
                pool.execute { serve(s) }
            }
        }
    }

    fun stop() { running = false; try { server?.close() } catch (_: Exception) {}; pool.shutdownNow() }

    private fun serve(s: Socket) {
        s.use {
            s.soTimeout = 3000
            val req = s.getInputStream().bufferedReader().readLine() ?: return
            val path = req.split(' ').getOrNull(1)?.substringBefore('?') ?: return
            val result = handler(path)                         // call once
            val body = (result ?: "").toByteArray(Charsets.UTF_8)
            val status = if (result == null) "404 Not Found" else "200 OK"
            val head = "HTTP/1.1 $status\r\nContent-Type: text/plain; charset=utf-8\r\n" +
                "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n"
            s.getOutputStream().apply { write(head.toByteArray()); write(body); flush() }
        }
    }
}
