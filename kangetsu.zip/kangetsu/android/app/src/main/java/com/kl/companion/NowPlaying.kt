package com.kl.companion

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import java.util.concurrent.Executors

/** What the HUD needs to know right now. pos is extrapolated to the moment of reading. */
data class Snapshot(
    val title: String, val artist: String, val album: String,
    val durMs: Long, val posMs: Long, val playing: Boolean, val pkg: String,
)

/** Reads the active media session (Spotify, YouTube Music, browser, ...). Needs notification access. */
object NowPlaying {
    private val ignored = setOf("org.levimc.launcher", "com.mojang.minecraftpe", "com.kl.companion")

    fun read(ctx: Context): Snapshot? {
        val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val listener = ComponentName(ctx, MediaWatcherService::class.java)
        val sessions: List<MediaController> = try {
            msm.getActiveSessions(listener)
        } catch (e: SecurityException) { return null }       // notification access not granted yet
        val c = sessions.filter { it.packageName !in ignored }
            .let { l -> l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull() }
            ?: return null
        val md = c.metadata ?: return null
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() } ?: return null
        val ps = c.playbackState
        val playing = ps?.state == PlaybackState.STATE_PLAYING
        var pos = ps?.position ?: 0L
        if (pos < 0) pos = 0                                  // PLAYBACK_POSITION_UNKNOWN
        if (playing && ps != null) {
            pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
        }
        return Snapshot(
            title = title,
            artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "",
            album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: "",
            durMs = md.getLong(MediaMetadata.METADATA_KEY_DURATION),
            posMs = pos, playing = playing, pkg = c.packageName,
        )
    }
}

/** Tracks song changes, owns the lyric download, and renders the plain-text protocol the mod reads. */
object State {
    private val worker = Executors.newSingleThreadExecutor()
    private var id = 0L
    private var key = ""
    @Volatile private var lines: List<LyricLine> = emptyList()
    @Volatile private var lyricsState = 0          // 0 loading, 1 ready, 2 none found

    private fun clean(s: String) = s.replace(Regex("[\t\r\n]"), " ")

    @Synchronized
    fun nowBody(ctx: Context): String {
        val s = NowPlaying.read(ctx) ?: return ""             // empty body = nothing playing
        val k = "${s.title}|${s.artist}|${s.durMs}"
        if (k != key) {
            key = k; id++; lines = emptyList(); lyricsState = 0
            val myId = id
            worker.execute {
                val found = try { Lyrics.find(s.title, s.artist, s.album, s.durMs) } catch (e: Exception) { emptyList() }
                synchronized(this) {
                    if (id == myId) { lines = found; lyricsState = if (found.isEmpty()) 2 else 1 }
                }
            }
        }
        return buildString {
            append("id\t$id\n")
            append("title\t${clean(s.title)}\n")
            append("artist\t${clean(s.artist)}\n")
            append("album\t${clean(s.album)}\n")
            append("dur\t${s.durMs}\n")
            append("pos\t${s.posMs}\n")
            append("playing\t${if (s.playing) 1 else 0}\n")
            append("lyrics\t$lyricsState\n")
        }
    }

    @Synchronized
    fun lyricsBody(): String = buildString {
        append("id\t$id\n")
        for (l in lines) append("${l.ms}\t${clean(l.text)}\n")
    }
}
