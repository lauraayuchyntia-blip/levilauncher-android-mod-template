package com.kl.companion

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** One synced lyric line. */
data class LyricLine(val ms: Long, val text: String)

/** LRC parsing + lrclib.net lookup (public lyrics service). */
object Lyrics {
    private val stamp = Regex("""\[(\d+):(\d+(?:[.:]\d+)?)]""")
    private val wordTag = Regex("""<\d+:\d+(?:[.:]\d+)?>""")

    fun parseLrc(text: String): List<LyricLine> {
        val out = ArrayList<LyricLine>()
        for (raw in text.split(Regex("\r?\n"))) {
            val stamps = stamp.findAll(raw).toList()
            if (stamps.isEmpty()) continue
            val lyric = raw.replace(stamp, "").replace(wordTag, "")
                .replace(Regex("[\u0000-\u001f\u00a7]"), "").trim()
            for (m in stamps) {
                val sec = m.groupValues[2].replace(':', '.').toDouble()
                out.add(LyricLine(Math.round((m.groupValues[1].toLong() * 60 + sec) * 1000), lyric))
            }
        }
        return out.sortedBy { it.ms }
    }

    fun cleanTitle(t: String): String = t
        .replace(Regex("""\s*[(\[][^)\]]*(feat|ft\.|remaster|live|version|official|lyric|video)[^)\]]*[)\]]""", RegexOption.IGNORE_CASE), "")
        .replace(Regex("""\s+-\s+(\d{4}\s+)?(remaster(ed)?|live|single version).*$""", RegexOption.IGNORE_CASE), "")
        .replace(Regex("\\s+"), " ").trim()

    fun firstArtist(a: String): String =
        a.split(Regex("""\s*(?:,|;|&|/|\sx\s|\sfeat\.?\s|\sft\.?\s)\s*""", RegexOption.IGNORE_CASE)).first().trim()

    private fun getJson(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "KangetsuLyrics-Companion/1.0 (Android)")
        if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
    } catch (e: Exception) { null }

    private fun q(vararg kv: Pair<String, String>) =
        kv.joinToString("&") { "${it.first}=${URLEncoder.encode(it.second, "UTF-8")}" }

    /** Returns synced lines, or an empty list if none were found. Blocking: call off the main thread. */
    fun find(title: String, artist: String, album: String, durMs: Long): List<LyricLine> {
        val t = cleanTitle(title); val a = firstArtist(artist); val dur = Math.round(durMs / 1000.0)
        getJson("https://lrclib.net/api/get?" + q("track_name" to t, "artist_name" to a,
            "album_name" to album, "duration" to dur.toString()))?.let {
            val s = JSONObject(it).optString("syncedLyrics", "")
            if (s.isNotBlank() && s != "null") return parseLrc(s)
        }
        val list = getJson("https://lrclib.net/api/search?" + q("track_name" to t, "artist_name" to a))
            ?.let { JSONArray(it) } ?: return emptyList()
        var fallback: String? = null
        for (i in 0 until list.length()) {
            val o = list.getJSONObject(i)
            val s = o.optString("syncedLyrics", "")
            if (s.isBlank() || s == "null") continue
            if (dur == 0L || Math.abs(o.optDouble("duration", 0.0) - dur) <= 5) return parseLrc(s)
            if (fallback == null) fallback = s
        }
        return fallback?.let { parseLrc(it) } ?: emptyList()
    }
}
