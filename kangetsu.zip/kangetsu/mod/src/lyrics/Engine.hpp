#pragma once
#include <atomic>
#include <functional>
#include <mutex>
#include <string>
#include <string_view>
#include <thread>
#include <vector>
#include "Protocol.hpp"

namespace kl {

struct Settings {
    bool enabled = true;
    bool showNext = true;
    bool intro = true;
    int size = 28;          // main lyric text size
    int offsetMs = 0;       // timing offset, + = lyrics earlier
    int x = 24;             // HUD position in pixels (see TODO about the HUD editor)
    int y = 140;
    uint32_t colour = 0xFFFFFFFFu;   // ARGB
    int port = 19133;       // companion app port
};

/** Polls the Android companion app, keeps the song clock, and draws lyrics on the HUD. */
class Engine {
public:
    using LogFn = std::function<void(const std::string&)>;

    bool start(const std::string& modId, const std::string& resourceDir, LogFn log);
    void stop();

    // called from Mod Menu callbacks
    void setEnabled(bool on);
    void setOption(std::string_view key, std::string_view value);

private:
    void pollLoop();
    void hudLoop();
    void fetchLyrics(int64_t id);
    void clearHud();

    std::string mModId, mModuleId, mFontId;
    LogFn mLog;
    std::atomic<bool> mRunning{false};
    std::thread mPoll, mHud;

    std::mutex mMutex;                 // guards everything below
    Settings mSettings;
    unsigned mRevision = 0;            // bumps on any setting change -> forces a HUD redraw
    int64_t mTrackId = 0, mLinesId = -1;
    std::string mTitle, mArtist;
    std::vector<Line> mLines;
    SongClock mClock;
    bool mConnected = false;
    std::chrono::steady_clock::time_point mTrackStart;
};

/** "#RRGGBB", "RRGGBB", "#AARRGGBB" or a plain decimal ARGB number -> 0xAARRGGBB. */
uint32_t parseColour(std::string_view s, uint32_t fallback);

} // namespace kl
