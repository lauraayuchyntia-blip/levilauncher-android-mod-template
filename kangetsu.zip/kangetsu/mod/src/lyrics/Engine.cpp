#include "Engine.hpp"

#include <pl/ModMenu.hpp>
#include <pl/Platform.hpp>

#include <cctype>
#include <fstream>
#include <iterator>

namespace kl {

namespace {
Engine* gEngine = nullptr;   // Mod Menu callbacks are plain functions; they reach us through this.

constexpr const char* ModuleName = "Kangetsu Lyrics";

void onToggle(std::string_view, bool on) { if (gEngine) gEngine->setEnabled(on); }
void onConfig(std::string_view, std::string_view key, std::string_view value) {
    if (gEngine) gEngine->setOption(key, value);
}

// ---------------------------------------------------------------------------------------------
// TODO(verify against include/pl/ModMenu.hpp): the docs only show DrawCommand fields for images
// (type, x, y, w, h, imageId) and say Text commands use `fontId`. The field names for the string,
// size and colour below are ASSUMED. If the build complains, this is the only place to fix.
// ---------------------------------------------------------------------------------------------
pl::modmenu::DrawCommand makeText(const std::string& fontId, const std::string& text,
                                  float x, float y, float size, uint32_t argb) {
    pl::modmenu::DrawCommand c{};
    c.type = pl::modmenu::DrawCommandType::Text;
    c.x = x; c.y = y;
    c.text = text;          // ASSUMED field name
    c.fontId = fontId;
    c.size = size;          // ASSUMED field name
    c.color = argb;         // ASSUMED field name
    return c;
}

uint32_t dim(uint32_t argb, int percent) {         // scale alpha, used for the "next line"
    uint32_t a = ((argb >> 24) & 0xFF) * percent / 100;
    return (a << 24) | (argb & 0x00FFFFFFu);
}
} // namespace

uint32_t parseColour(std::string_view s, uint32_t fallback) {
    std::string t(s);
    if (!t.empty() && t[0] == '#') t.erase(0, 1);
    if (t.empty()) return fallback;
    for (char c : t) if (!std::isxdigit(static_cast<unsigned char>(c))) return fallback;
    if (t.size() == 6 || t.size() == 8) {            // hex: RRGGBB or AARRGGBB
        uint32_t v = static_cast<uint32_t>(std::strtoul(t.c_str(), nullptr, 16));
        return t.size() == 6 ? (0xFF000000u | v) : v;
    }
    for (char c : t) if (!std::isdigit(static_cast<unsigned char>(c))) return fallback;
    return static_cast<uint32_t>(std::strtoul(t.c_str(), nullptr, 10));   // plain decimal ARGB
}

bool Engine::start(const std::string& modId, const std::string& resourceDir, LogFn log) {
    if (mRunning) return true;
    mModId = modId; mModuleId = modId + ".lyrics"; mLog = std::move(log);
    gEngine = this;

    // Optional custom font: drop a TTF named lyrics.ttf into the mod's resource folder.
    std::ifstream f(resourceDir + "/lyrics.ttf", std::ios::binary);
    if (f) {
        std::vector<unsigned char> ttf((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
        mFontId = modId + ".font";
        if (!pl::modmenu::registerFont(mFontId, ttf)) { mLog("registerFont failed, using default font"); mFontId.clear(); }
    }

    namespace mm = pl::modmenu;
    bool ok = mm::ModuleBuilder(mModuleId, ModuleName)
        .modId(mModId)
        .description("Synced song lyrics on your HUD. Needs the Kangetsu Lyrics Companion app.")
        .defaultEnabled(true)
        .onToggle(onToggle)
        .onConfigChanged(onConfig)
        .config("showNext", "Show next line", mm::ConfigType::Toggle, "true")
        .config("intro", "Song title intro", mm::ConfigType::Toggle, "true")
        .config("size", "Text size", mm::ConfigType::SliderInt, "28", "14", "64")
        .config("offset", "Timing offset (ms)", mm::ConfigType::SliderInt, "0", "-3000", "3000")
        .config("x", "Position X", mm::ConfigType::SliderInt, "24", "0", "1200")
        .config("y", "Position Y", mm::ConfigType::SliderInt, "140", "0", "1000")
        .config("colour", "Colour", mm::ConfigType::Color, "#FFFFFF")
        .config("port", "Companion port", mm::ConfigType::Text, "19133")
        .registerModule();
    if (!ok) { mLog("registerModule failed"); return false; }

    mRunning = true;
    mPoll = std::thread([this] { pollLoop(); });
    mHud = std::thread([this] { hudLoop(); });
    return true;
}

void Engine::stop() {
    if (!mRunning.exchange(false)) return;
    if (mPoll.joinable()) mPoll.join();
    if (mHud.joinable()) mHud.join();
    pl::modmenu::submitDrawCommands(mModuleId, {});
    pl::modmenu::unregisterModule(mModuleId);
    gEngine = nullptr;
}

void Engine::setEnabled(bool on) {
    { std::lock_guard<std::mutex> g(mMutex); mSettings.enabled = on; ++mRevision; }
    if (!on) clearHud();
}

void Engine::setOption(std::string_view key, std::string_view value) {
    std::lock_guard<std::mutex> g(mMutex);
    const std::string v(value);
    auto num = [&](int lo, int hi, int cur) {
        char* end = nullptr; long n = std::strtol(v.c_str(), &end, 10);
        return end == v.c_str() ? cur : static_cast<int>(std::max<long>(lo, std::min<long>(hi, n)));
    };
    if (key == "showNext") mSettings.showNext = v == "true" || v == "1";
    else if (key == "intro") mSettings.intro = v == "true" || v == "1";
    else if (key == "size") mSettings.size = num(8, 128, mSettings.size);
    else if (key == "offset") mSettings.offsetMs = num(-10000, 10000, mSettings.offsetMs);
    else if (key == "x") mSettings.x = num(0, 4000, mSettings.x);
    else if (key == "y") mSettings.y = num(0, 4000, mSettings.y);
    else if (key == "colour") mSettings.colour = parseColour(v, mSettings.colour);
    else if (key == "port") mSettings.port = num(1024, 65535, mSettings.port);
    ++mRevision;
}

void Engine::clearHud() { pl::modmenu::submitDrawCommands(mModuleId, {}); }

void Engine::fetchLyrics(int64_t id) {
    int port; { std::lock_guard<std::mutex> g(mMutex); port = mSettings.port; }
    auto r = pl::platform::httpGet("http://127.0.0.1:" + std::to_string(port) + "/lyrics", 2500);
    if (!r.ok()) return;
    int64_t gotId = 0;
    auto lines = parseLyrics(r.body, &gotId);
    if (gotId != id) return;                       // song changed while downloading
    std::lock_guard<std::mutex> g(mMutex);
    if (mTrackId == id) { mLines = std::move(lines); mLinesId = id; }
}

void Engine::pollLoop() {
    using namespace std::chrono_literals;
    while (mRunning) {
        int port; bool enabled;
        { std::lock_guard<std::mutex> g(mMutex); port = mSettings.port; enabled = mSettings.enabled; }
        int waitMs = 700;
        if (enabled) {
            auto r = pl::platform::httpGet("http://127.0.0.1:" + std::to_string(port) + "/now", 1200);
            if (!r.ok()) {
                std::lock_guard<std::mutex> g(mMutex);
                if (mConnected) mLog("companion unreachable");
                mConnected = false; waitMs = 2000;
            } else {
                Now n = parseNow(r.body);
                bool needLyrics = false; int64_t id = 0;
                {
                    std::lock_guard<std::mutex> g(mMutex);
                    if (!mConnected) mLog("companion connected");
                    mConnected = true;
                    if (!n.valid) { mLines.clear(); mTrackId = 0; mLinesId = -1; mClock.sync(0, false); }
                    else {
                        if (n.id != mTrackId) {
                            mTrackId = n.id; mTitle = n.title; mArtist = n.artist;
                            mLines.clear(); mLinesId = -1; mTrackStart = std::chrono::steady_clock::now();
                        }
                        mClock.sync(n.posMs, n.playing);
                        if (n.lyrics == 1 && mLinesId != n.id) { needLyrics = true; id = n.id; }
                    }
                }
                if (needLyrics) fetchLyrics(id);
            }
        }
        for (int i = 0; i < waitMs && mRunning; i += 50) std::this_thread::sleep_for(50ms);
    }
}

void Engine::hudLoop() {
    using namespace std::chrono_literals;
    int lastIdx = -2; unsigned lastRev = ~0u; bool lastIntro = false, lastShown = false;
    while (mRunning) {
        std::vector<pl::modmenu::DrawCommand> cmds;
        bool shown = false, intro = false; int idx = -1; unsigned rev = 0;
        {
            std::lock_guard<std::mutex> g(mMutex);
            rev = mRevision;
            if (mSettings.enabled && mTrackId != 0) {
                const auto& s = mSettings;
                const float x = static_cast<float>(s.x), y = static_cast<float>(s.y), sz = static_cast<float>(s.size);
                auto since = std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now() - mTrackStart).count();
                intro = s.intro && !mTitle.empty() && since < 4000;
                idx = findLine(mLines, mClock.now() + s.offsetMs);
                if (intro) {
                    cmds.push_back(makeText(mFontId, "\xE2\x99\xAA " + mTitle, x, y, sz + 6, s.colour));
                    cmds.push_back(makeText(mFontId, mArtist, x, y + sz + 12, sz * 0.7f, dim(s.colour, 70)));
                    shown = true;
                } else if (idx >= 0 && mClock.playing()) {
                    cmds.push_back(makeText(mFontId, displayText(mLines, idx), x, y, sz, s.colour));
                    if (s.showNext && idx + 1 < static_cast<int>(mLines.size()))
                        cmds.push_back(makeText(mFontId, displayText(mLines, idx + 1), x, y + sz + 10, sz * 0.75f, dim(s.colour, 55)));
                    shown = true;
                }
            }
        }
        if (idx != lastIdx || rev != lastRev || intro != lastIntro || shown != lastShown) {
            pl::modmenu::submitDrawCommands(mModuleId, cmds);   // empty list clears the overlay
            lastIdx = idx; lastRev = rev; lastIntro = intro; lastShown = shown;
        }
        std::this_thread::sleep_for(66ms);
    }
}

} // namespace kl
