#include "../src/lyrics/Engine.hpp"
#include <cassert>
#include <iostream>
int main() {
    using kl::parseColour; const uint32_t fb = 0x11223344u;
    assert(parseColour("#FFFFFF", fb) == 0xFFFFFFFFu);
    assert(parseColour("ff8800", fb) == 0xFFFF8800u);
    assert(parseColour("#80FF0000", fb) == 0x80FF0000u);
    assert(parseColour("4294967295", fb) == 0xFFFFFFFFu);
    assert(parseColour("", fb) == fb && parseColour("zzz", fb) == fb && parseColour("#12", fb) == 12u);
    std::cout << "colour tests OK\n";
}
