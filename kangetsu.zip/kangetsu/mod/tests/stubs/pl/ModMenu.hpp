// STUB written from the public docs, ONLY to catch typos in Engine.cpp. Not the real SDK.
#pragma once
#include <string>
#include <string_view>
#include <vector>
#include <cstdint>
namespace pl::modmenu {
enum class ConfigType { Toggle, SliderInt, SliderFloat, Radio, Color, Keybind, Text, Button };
enum class DrawCommandType { Text, Image };
struct DrawCommand { DrawCommandType type{}; float x{}, y{}, w{}, h{}; std::string fontId, imageId;
                     std::string text; float size{}; uint32_t color{}; };   // text/size/color = assumed
class ModuleBuilder { public:
  ModuleBuilder(std::string_view, std::string_view) {}
  ModuleBuilder& modId(std::string_view) { return *this; }
  ModuleBuilder& description(std::string_view) { return *this; }
  ModuleBuilder& defaultEnabled(bool) { return *this; }
  ModuleBuilder& onToggle(void (*)(std::string_view, bool)) { return *this; }
  ModuleBuilder& onConfigChanged(void (*)(std::string_view, std::string_view, std::string_view)) { return *this; }
  ModuleBuilder& config(std::string_view, std::string_view, ConfigType, std::string_view,
                        std::string_view = "", std::string_view = "") { return *this; }
  bool registerModule() { return true; } };
inline bool registerFont(std::string_view, const std::vector<unsigned char>&) { return true; }
inline bool submitDrawCommands(std::string_view, const std::vector<DrawCommand>&) { return true; }
inline void unregisterModule(std::string_view) {}
}
