#pragma once
#include <string>
namespace pl::platform {
struct HttpResponse { int status = 0; std::string body; int retryAfter = 0; bool ok() const { return status >= 200 && status < 300; } };
inline HttpResponse httpGet(const std::string&, int = 5000) { return {}; }
}
