#include "../src/lyrics/Protocol.hpp"
#include <cassert>
#include <iostream>
using namespace kl;

int main() {
    Now n = parseNow("id\t7\ntitle\tSong \xE6\x9C\x88\nartist\tA\nalbum\t\ndur\t200000\npos\t12345\nplaying\t1\nlyrics\t1\n");
    assert(n.valid && n.id == 7 && n.title == "Song \xE6\x9C\x88" && n.durMs == 200000 && n.posMs == 12345);
    assert(n.playing && n.lyrics == 1 && n.album.empty());
    assert(!parseNow("").valid);
    assert(!parseNow("garbage without tabs\r\n").valid);

    int64_t id = 0;
    auto L = parseLyrics("id\t7\r\n5000\tsecond\r\n1000\tfirst\r\nxx\tjunk\r\n9000\t\r\n12000\ta\tb\r\n", &id);
    assert(id == 7 && L.size() == 4);
    assert(L[0].ms == 1000 && L[0].text == "first" && L[1].text == "second");
    assert(L[3].text == "a\tb");

    assert(findLine(L, 0) == -1 && findLine(L, 1000) == 0 && findLine(L, 4999) == 0);
    assert(findLine(L, 5000) == 1 && findLine(L, 10000) == 2 && findLine(L, 10000000) == 3);
    assert(findLine({}, 100) == -1);

    assert(displayText(L, 2) == "\xE2\x99\xAA \xE2\x99\xAA \xE2\x99\xAA");
    assert(displayText(L, 99).empty());

    SongClock c; auto t0 = SongClock::Clock::now();
    c.sync(10000, true, t0);
    assert(c.now(t0 + std::chrono::milliseconds(1500)) == 11500);
    c.sync(10000, false, t0);
    assert(c.now(t0 + std::chrono::seconds(9)) == 10000);

    std::cout << "protocol tests OK\n";
}
