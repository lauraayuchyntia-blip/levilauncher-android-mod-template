# Edits to the official template (QYCottage/levilauncher-android-mod-template)

1. Copy `mod/src/lyrics/` into the template's `src/` folder.
2. In `CMakeLists.txt`, add `src/lyrics/Engine.cpp` to the library's source list
   (and make sure `src` is an include directory; the template already includes its own `src/mod`).
3. Edit `src/mod/MyMod.cpp`:

```cpp
#include "../lyrics/Engine.hpp"
namespace { kl::Engine gLyrics; }

bool ClangeMeMod::enable() {
    getSelf().getLogger().info("Enabling...");
    return gLyrics.start(getSelf().getId(), getSelf().getResourceDir().string(),
                         [this](const std::string& m) { getSelf().getLogger().info(m); });
}
bool ClangeMeMod::disable() {
    gLyrics.stop();
    return true;
}
```
4. In `CMakeLists.txt` set:
   MOD_ID=kangetsu_lyrics_port  MOD_NAME="Kangetsu Lyrics (port)"  MOD_LIBRARY_NAME=kangetsu_lyrics_port
   MOD_MINECRAFT_VERSIONS='[]'   (empty = every version; we use no game offsets/hooks)
5. Optional font: put `assets/lyrics.ttf` in the mod's resource folder on the phone.
